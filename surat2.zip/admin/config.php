<?php
mysql_connect("localhost:3308","root","1");
mysql_select_db("surat");
?>
